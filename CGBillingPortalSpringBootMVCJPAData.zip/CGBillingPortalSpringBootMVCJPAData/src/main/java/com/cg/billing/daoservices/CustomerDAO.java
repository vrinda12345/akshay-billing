package com.cg.billing.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.billing.beans.Customer;

public interface CustomerDAO extends JpaRepository<Customer, Integer>{

	//Pending
	@Query("delete from Customer c where c.customerID=:customerId")
	boolean delete(@Param("customerId") int customerId);
}
