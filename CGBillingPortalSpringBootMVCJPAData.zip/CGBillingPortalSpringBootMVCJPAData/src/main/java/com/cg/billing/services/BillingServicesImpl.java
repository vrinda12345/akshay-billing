package com.cg.billing.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.billing.beans.Address;
import com.cg.billing.beans.Admin;
import com.cg.billing.beans.Bill;
import com.cg.billing.beans.Customer;
import com.cg.billing.beans.Plan;
import com.cg.billing.beans.PostpaidAccount;
import com.cg.billing.daoservices.AdminDAO;
import com.cg.billing.daoservices.BillDAO;
import com.cg.billing.daoservices.CustomerDAO;
import com.cg.billing.daoservices.PlanDAO;
import com.cg.billing.daoservices.PostpaidAccountDAO;
import com.cg.billing.exceptions.BillDetailsNotFoundException;
import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.exceptions.InvalidBillMonthException;
import com.cg.billing.exceptions.PlanDetailsNotFoundException;
import com.cg.billing.exceptions.PostpaidAccountNotFoundException;

@Component("billingServices")
public class BillingServicesImpl implements BillingServices {

	@Autowired
	private CustomerDAO customerServices;
	@Autowired
	private PlanDAO planServices;
	@Autowired
	private PostpaidAccountDAO postpaidServices;
	@Autowired
	private  BillDAO billServices;
	@Autowired
	private AdminDAO adminServices;

	@Override
	public List<Plan> getPlanAllDetails() {
		return planServices.findAll();
	}

	@Override
	public Customer acceptCustomerDetails(Customer customer) {
		customerServices.save(customer);
		return customer;
	}

	@Override
	public long openPostpaidMobileAccount(int customerID, int planID) throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException {
		Customer customer = customerServices.findById(customerID).orElseThrow(()-> new CustomerDetailsNotFoundException("Invalid customer Id"));
		Plan plan = planServices.findById(planID).orElseThrow(()-> new PlanDetailsNotFoundException("Plan details not found"));
		PostpaidAccount postpaidAccount = new PostpaidAccount(plan, customer, null);
		postpaidAccount = postpaidServices.save(postpaidAccount);
		return postpaidAccount.getMobileNo();
	}

	@Override
	public double generateMonthlyMobileBill(int customerID, long mobileNo, String billMonth, int noOfLocalSMS,
			int noOfStdSMS, int noOfLocalCalls, int noOfStdCalls, int internetDataUsageUnits) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException {
		
		customerServices.findById(customerID).orElseThrow(()-> new CustomerDetailsNotFoundException("Invalid customer Id"));
		PostpaidAccount postpaidAccount = postpaidServices.findById(mobileNo).orElseThrow(()-> new PostpaidAccountNotFoundException("Cant find PostPaid account"));
			if(billMonth.equalsIgnoreCase("jan") || billMonth.equalsIgnoreCase("feb") || billMonth.equalsIgnoreCase("mar") || billMonth.equalsIgnoreCase("apr") || billMonth.equalsIgnoreCase("may") || billMonth.equalsIgnoreCase("jun") || billMonth.equalsIgnoreCase("jul") || billMonth.equalsIgnoreCase("aug") || billMonth.equalsIgnoreCase("sep") || billMonth.equalsIgnoreCase("oct") || billMonth.equalsIgnoreCase("nov") || billMonth.equalsIgnoreCase("dec")) {
				Bill bill=new Bill(noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfStdCalls, internetDataUsageUnits, billMonth, 10000, 5, 5, 10, 10, 10);
				bill = billServices.save(bill);
				postpaidAccount.getBills().put(bill.getBillID(), bill);
				postpaidServices.save(postpaidAccount);
				return bill.getTotalBillAmount();
			} else throw new InvalidBillMonthException("Invalid Bill Month");
	}

	@Override
	public Customer getCustomerDetails(int customerID) throws CustomerDetailsNotFoundException {
		return customerServices.findById(customerID).orElseThrow(()-> new CustomerDetailsNotFoundException("Invalid customer Id"));
	}

	@Override
	public List<Customer> getAllCustomerDetails() {
		return customerServices.findAll();
	}

	@Override
	public PostpaidAccount getPostPaidAccountDetails(int customerID,long mobileNo) throws CustomerDetailsNotFoundException,PostpaidAccountNotFoundException { 
		return null;
	}

	@Override
	public List<PostpaidAccount> getCustomerAllPostpaidAccountsDetails(int customerID) throws CustomerDetailsNotFoundException {
		customerServices.findById(customerID).orElseThrow(()-> new CustomerDetailsNotFoundException("Invalid customer Id"));
		return postpaidServices.findAll(customerID);
	}

	@Override
	public Bill getMobileBillDetails(int customerID, long mobileNo, String billMonth) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,BillDetailsNotFoundException {

		customerServices.findById(customerID).orElseThrow(()-> new CustomerDetailsNotFoundException("Invalid customer Id"));
		PostpaidAccount postpaidAccount = postpaidServices.findOne(customerID, mobileNo);
		if(postpaidAccount != null) {
			if(billMonth.equalsIgnoreCase("jan") || billMonth.equalsIgnoreCase("feb") || billMonth.equalsIgnoreCase("mar") || billMonth.equalsIgnoreCase("apr") || billMonth.equalsIgnoreCase("may") || billMonth.equalsIgnoreCase("jun") || billMonth.equalsIgnoreCase("jul") || billMonth.equalsIgnoreCase("aug") || billMonth.equalsIgnoreCase("sep") || billMonth.equalsIgnoreCase("oct") || billMonth.equalsIgnoreCase("nov") || billMonth.equalsIgnoreCase("dec")) {
				for(Bill bill: postpaidAccount.getBills().values()) {
					if(bill.getBillMonth().equalsIgnoreCase(billMonth))
						return bill;
				}
				throw new BillDetailsNotFoundException("Bill details not found");
			} else throw new InvalidBillMonthException("Invalid Bill Month");
		} else throw new PostpaidAccountNotFoundException("Cant find PostPaid account");
	}

	@Override
	public List<Bill> getCustomerPostPaidAccountAllBillDetails(int customerID, long mobileNo) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		customerServices.findById(customerID).orElseThrow(()-> new CustomerDetailsNotFoundException("Invalid customer Id"));
		PostpaidAccount postpaidAccount = postpaidServices.findOne(customerID, mobileNo);
		if(postpaidAccount != null) {
			return new ArrayList<Bill>(postpaidAccount.getBills().values());
		} else throw new PostpaidAccountNotFoundException("Cant find PostPaid account");
	}

	@Override
	public boolean changePlan(int customerID, long mobileNo, int planID) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, PlanDetailsNotFoundException {
		customerServices.findById(customerID).orElseThrow(()-> new CustomerDetailsNotFoundException("Invalid customer Id"));
		PostpaidAccount postpaidAccount = postpaidServices.findOne(customerID, mobileNo);
		if(postpaidAccount != null) {
			Plan plan = planServices.findById(planID).orElseThrow(()-> new PlanDetailsNotFoundException("Plan details not found"));
			postpaidAccount.setPlan(plan);
			postpaidServices.save(postpaidAccount);
			return true;
		} else throw new PostpaidAccountNotFoundException("Cant find PostPaid account");
	}

	@Override
	public boolean closeCustomerPostPaidAccount(int customerID, long mobileNo) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		customerServices.findById(customerID).orElseThrow(()-> new CustomerDetailsNotFoundException("Invalid customer Id"));
		PostpaidAccount postpaidAccount = postpaidServices.findOne(customerID, mobileNo);
		if(postpaidAccount != null) {
			postpaidServices.delete(postpaidAccount.getMobileNo());
			return true;
		} else throw new PostpaidAccountNotFoundException("Cant find PostPaid account");
	}

	@Override
	public boolean removeCustomerDetails(int customerID) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		customerServices.findById(customerID).orElseThrow(()-> new CustomerDetailsNotFoundException("Invalid customer Id"));
		for(PostpaidAccount postpaidAccount: getCustomerAllPostpaidAccountsDetails(customerID)) {
			closeCustomerPostPaidAccount(customerID, postpaidAccount.getMobileNo());
		}
		return customerServices.delete(customerID);
	}

	@Override
	public Plan getCustomerPostPaidAccountPlanDetails(int customerID, long mobileNo) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, PlanDetailsNotFoundException {

		customerServices.findById(customerID).orElseThrow(()-> new CustomerDetailsNotFoundException("Invalid customer Id"));
		PostpaidAccount postpaidAccount = postpaidServices.findOne(customerID, mobileNo);
		if(postpaidAccount != null) {
			Plan plan = postpaidAccount.getPlan();
			if(plan != null) return postpaidAccount.getPlan();
			else throw new PlanDetailsNotFoundException("Plan details no found");
		} else throw new PostpaidAccountNotFoundException("Cant find PostPaid account");
	}

	@Override
	public boolean validateCustomer(String customerID, String password) throws CustomerDetailsNotFoundException {
		int id = Integer.parseInt(customerID);
		return customerServices.findById(id).orElseThrow(()-> new CustomerDetailsNotFoundException("Invalid customer Id")).getPassword().equals(password);
	}

	@Override
	public boolean validateAdmin(String userName, String password) throws CustomerDetailsNotFoundException {
		Admin admin = adminServices.findById(userName).orElseThrow(()-> new CustomerDetailsNotFoundException("Invalid User Name"));
		if(admin.getPassword().equals(password)) 
			throw new CustomerDetailsNotFoundException("Password is incorrect");
		return true;
	}

	@Override
	public boolean checkCredentials(String userName, String password) throws CustomerDetailsNotFoundException {
		try {
			if(validateCustomer(userName, password))
				return true;
		} catch (CustomerDetailsNotFoundException e) {
			
		}
		return false;
	}
	
}
